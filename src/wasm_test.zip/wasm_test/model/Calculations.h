

#ifndef CALCULATIONS_H
#define CALCULATIONS_H



#include <string>

using namespace std;

// Does some maths
class Calculations{


	public:
		Calculations(); // Constructor
		double add(double n1, double n2); // Adds two numbers together



};

#endif