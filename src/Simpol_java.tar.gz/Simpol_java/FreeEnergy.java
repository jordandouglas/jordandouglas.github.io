import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class FreeEnergy {

	
	
	
	public static HashMap<String, Double> basepairingEnergy = null;
	
	
	
	public static void init(){
		
		init_BP_parameters();
		
	}
	
	
	public static double getFreeEnergyOfHybrid(CompressedState s){
		String[] hybridStrings = FreeEnergy.getHybridString(s);
		double hybridFreeEnergy = FreeEnergy.getHybridFreeEnergy(hybridStrings[0], hybridStrings[1], Settings.TemplateType.substring(2), Settings.PrimerType.substring(2));
		return hybridFreeEnergy;
	}
	
	
	
	// Returns the increase in free energy which the double stranded template would have if the transcription bubble was sealed
	// leftmostTemplatePos is the last base in the template which is basepairing before the bubble (e in the example below)
	// complementary    ABCDEFGHIJKLM
	// template         abcde	 jklm
	// template              fghi
	// primer                1234
	public static double getFreeEnergyOfTranscriptionBubble(CompressedState s){
		
		if (Settings.TemplateType.substring(0, 2).equals("ss")) return 0;
		
		double bubbleFreeEnergy = 0;
		
		int leftmostTemplatePos = s.getLeftBaseNumber() - (int)Settings.currentModel.getParameter("bubbleLeft").getVal() - 2;
		int leftmostComplementPos = leftmostTemplatePos;
		int rightmostTemplatePos = s.getRightBaseNumber() + (int)Settings.currentModel.getParameter("bubbleRight").getVal();
		int rightmostComplementPos = rightmostTemplatePos;
		String[] hybridStrings = getHybridStringOfTranscriptionBubble(leftmostTemplatePos, rightmostTemplatePos, leftmostComplementPos, rightmostComplementPos);
		
		//System.out.println("bubble hybrid strings " + hybridStrings[0] + "/" + hybridStrings[1] );
		
		
		
		bubbleFreeEnergy = getFreeEnergyOfTranscriptionBubbleHybridString(hybridStrings[0], hybridStrings[1], Settings.TemplateType.substring(2));
		
		
		return bubbleFreeEnergy;
		
		
	}
	
	
	public static double getFreeEnergyOfIntermediateState(CompressedState state1, CompressedState state2){
		
		double freeEnergy = 0;

		
		String[] hybridStrings1 = getHybridString(state1);
		String[] hybridStrings2 = getHybridString(state2);
		
		String[] intermediateString = getHybridIntermediateString(hybridStrings1, hybridStrings2, state1.getLeftBaseNumber(), state2.getLeftBaseNumber());
		
		
		freeEnergy = getHybridFreeEnergy(intermediateString[0], intermediateString[1], Settings.TemplateType.substring(2), Settings.PrimerType.substring(2));
		
		
		
		return freeEnergy;
		
	}
	
	
	public static double getFreeEnergyOfTranscriptionBubbleIntermediate(CompressedState state1, CompressedState state2){
		
		if (Settings.TemplateType.substring(0, 2).equals("ss")) return 0;
		double freeEnergy = 0;
		
		int leftmostTemplatePos = Math.min(state1.getLeftBaseNumber(), state2.getLeftBaseNumber()) - (int)Settings.currentModel.getParameter("bubbleLeft").getVal() - 2;
		int leftmostComplementPos = leftmostTemplatePos;
		int rightmostTemplatePos = Math.max(state1.getRightBaseNumber(), state2.getRightBaseNumber()) + (int)Settings.currentModel.getParameter("bubbleRight").getVal();
		int rightmostComplementPos = rightmostTemplatePos;


		// Take the intersection of missing basepairs if going for the sealing model
		if (Settings.currentModel.get_currentTranslocationModel().equals("sealingBarriers")){
			leftmostTemplatePos ++;
			leftmostComplementPos ++;
			rightmostTemplatePos --;
			rightmostComplementPos --;
		}

		
		String[] hybridStrings = getHybridStringOfTranscriptionBubble(leftmostTemplatePos, rightmostTemplatePos, leftmostComplementPos, rightmostComplementPos);
		
		
		//System.out.println("hybridStrings " + hybridStrings[0] + "/" +  hybridStrings[1]);
		
		freeEnergy = getFreeEnergyOfTranscriptionBubbleHybridString(hybridStrings[0], hybridStrings[1], Settings.TemplateType.substring(2));
		
		return freeEnergy;
		
	}
	
	
	
	
	private static String[] getHybridString(CompressedState s){
		
		
		String templateString = "";
		String nascentString = "";
		int stopWhenAt = (int)Settings.currentModel.getParameter("hybridLen").getVal();
		int rightBase = s.getRightBaseNumber();
		int leftBase = s.getLeftBaseNumber();
		
		
		//System.out.println("rightBase " + rightBase + " leftBase " + leftBase);
		
		// Unnecessarily complex to account for bulges in the future
		for (int hybridPos = 0; hybridPos < stopWhenAt; hybridPos++){
			
			
			int baseNum = rightBase - hybridPos;

			
			// Go to next base if this one does not exist
			if (baseNum < 0 || baseNum < leftBase || baseNum > Settings.seq.length() || baseNum > s.get_nascentLength()) continue;
			
			String gBase = Settings.seq.substring(baseNum-1, baseNum);
			String nBase = s.get_NascentSequence().substring(baseNum-1, baseNum);
			
			templateString = gBase + templateString;
			nascentString = nBase + nascentString;
			
		}
		
		return new String[] { templateString, nascentString };
		
	}
	
	private static String[] getHybridStringOfTranscriptionBubble(int leftmostTemplatePos, int rightmostTemplatePos, int leftmostComplementPos, int rightmostComplementPos){
		
		// Build strings
		
		// template   3' AACGATTCGAT
		// complement 5' TTGCTAAGCTA
		String templateString = "";
		String complementString = "";
		
		//System.out.println("leftmostTemplatePos " + leftmostTemplatePos + " rightmostTemplatePos " + rightmostTemplatePos);
		
		for (int i = leftmostTemplatePos; i <= rightmostTemplatePos; i ++){
			if (i < 1) continue;
			if (i >= Settings.seq.length()) break;
			templateString += Settings.seq.substring(i, i+1);
		}
		for (int i = leftmostComplementPos; i <= rightmostComplementPos; i ++){
			if (i < 1) continue;
			if (i >= Settings.seq.length()) break;
			complementString += Settings.complementSeq.substring(i, i+1);
		}
		
		
		
		return new String[] { templateString, complementString };
		
		
	}
	
	
	private static String[] getHybridIntermediateString(String[] hybridStrings1, String[] hybridStrings2, int left1, int left2){
		
		
		// Build a list of basepairs between template and hybrid in each sequence
		ArrayList<String> basepairs1 = getBasePairs(hybridStrings1[0], hybridStrings1[1], left1);
		ArrayList<String> basepairs2 = getBasePairs(hybridStrings2[0], hybridStrings2[1], left2);
		
		
		
		// Find the basepairs which are in both sets (ie. the intersection)
		ArrayList<String> basepairsIntermediate = (ArrayList<String>) intersection(basepairs1, basepairs2);
		
		
		//System.out.println("basepairs1 " + basepairs1 + " basepairs2 " + basepairs2);
		//System.out.println("XXXX " + basepairsIntermediate);
		
		
		
		// Convert the intermediate basepairs back into a string
		String strIntermediateT = "";
		String strIntermediateN = "";
		for (int i = 0; i <  basepairsIntermediate.size(); i ++){
			
			
			int baseNum1 = Integer.parseInt(basepairsIntermediate.get(i).split("_")[0]);
			int baseIndex = baseNum1 - left1;
			
			
			String Tbase = hybridStrings1[0].substring(baseIndex, baseIndex+1); // Intersection means that either string1 or string2 can be used
			String Nbase = hybridStrings1[1].substring(baseIndex, baseIndex+1);
			
			strIntermediateT += Tbase;
			strIntermediateN += Nbase;
			
			
		}
		
		return new String[] { strIntermediateT, strIntermediateN };
		
	}
	
	
	
	// Returns a list of basepairs (by index) in the two strings
	private static ArrayList<String> getBasePairs(String templateString, String nascentString, int leftT){
		
		
		ArrayList<String> basePairs = new ArrayList<String>();
		int templateIndex = 0;
		int primerIndex = 0;
		

		while(true){
			

			
			// If we have exceeded the string lengths then exit
			if (templateIndex >= templateString.length() || primerIndex >= nascentString.length()) break;
			
			
			// If both are uppercase then they are basepaired
			//if (isUpperCase_WW(strT[templateIndex]) && isUpperCase_WW(strP[primerIndex])){
				
				basePairs.add("" + (templateIndex + leftT) + "_" + (primerIndex + leftT));
				templateIndex++;
				primerIndex++;
			//}
			
			
			/*
			// If only one is uppercase then skip the other one
			else if (isUpperCase_WW(strT[templateIndex]) & !isUpperCase_WW(strP[primerIndex])){
				primerIndex++;
			}
			else if (!isUpperCase_WW(strT[templateIndex]) & isUpperCase_WW(strP[primerIndex])){
				templateIndex++;
			}
			
			
			// If neither are uppercase then skip both
			else if (!isUpperCase_WW(strT[templateIndex]) && !isUpperCase_WW(strP[primerIndex])){
				templateIndex++;
				primerIndex++;
			}
			*/
			
		}
		
		return basePairs;
		
		
	}
	
	
	private static double getHybridFreeEnergy(String templateString, String nascentString, String templateType, String nascentType){
		
		//System.out.println(templateString + "|" + nascentString);
		
		
		double freeEnergy = 0;
		
		for (int hybridPos = 0; hybridPos < Math.min(templateString.length(), nascentString.length()) - 1; hybridPos ++){
			
			String thisNBase = nascentString.substring(hybridPos, hybridPos+1);
			String thisGBase = templateString.substring(hybridPos, hybridPos+1);
			
			String nextNBase = nascentString.substring(hybridPos+1, hybridPos+2);
			String nextGBase = templateString.substring(hybridPos+1, hybridPos+2);
			
			if (templateType.equals("DNA")){
				thisGBase = "d" + thisGBase;
				nextGBase = "d" + nextGBase;
			}
			if (nascentType.equals("DNA")){
				thisNBase = "d" + thisNBase;
				nextNBase = "d" + nextNBase;
			}
			String dictKey = thisNBase + nextNBase + thisGBase + nextGBase;
			Double energy = FreeEnergy.basepairingEnergy.get(dictKey);
			
			//System.out.println("Looking for dictkey " + dictKey + " found " + energy);
			if (energy == null) freeEnergy += 2; // TODO: need to find dGU basepairing parameters 
			else freeEnergy += energy;
			
		}
		
		
		return freeEnergy / Settings.RT;
		
	}
	
	
	private static double getFreeEnergyOfTranscriptionBubbleHybridString(String templateString, String complementString, String templateType){
		
		double freeEnergy = 0;
		//System.out.println(complementString + "\n" + templateString);
		for (int i = 0; i < templateString.length()-1; i ++){
			
			String d = templateType.equals("DNA") ? "d" : "";
			String thisTemplateBase = d + templateString.substring(i, i+1);
			String thisComplementBase = d + complementString.substring(i, i+1);
			String nextTemplateBase = d + templateString.substring(i+1, i+2);
			String nextComplementBase = d + complementString.substring(i+1, i+2);
			
			String dictKey = thisComplementBase + nextComplementBase + thisTemplateBase + nextTemplateBase;
			Double energy = FreeEnergy.basepairingEnergy.get(dictKey);
			//System.out.println("Looking for dictkey " + dictKey + " found " + energy);
			if (energy == null) freeEnergy += 2; // TODO: need to find dGU basepairing parameters 
			else freeEnergy += energy;
			
		}
		
		return freeEnergy / Settings.RT;
	}
	
	
	
	
	 private static <T> List<T> union(List<T> list1, List<T> list2) {
	        Set<T> set = new HashSet<T>();

	        set.addAll(list1);
	        set.addAll(list2);

	        return new ArrayList<T>(set);
	    }

    private static <T> List<T> intersection(List<T> list1, List<T> list2) {
        List<T> list = new ArrayList<T>();

        for (T t : list1) {
            if(list2.contains(t)) {
                list.add(t);
            }
        }

        return list;
    }
	
	
	private static void init_BP_parameters(){
		
		basepairingEnergy = new HashMap<String, Double>();
		
		// RNA-RNA
		basepairingEnergy.put("AAUU", -0.93);
		basepairingEnergy.put("UUAA", -0.93);
		basepairingEnergy.put("AUUA", -1.10);
		basepairingEnergy.put("UAAU", -1.33);
		basepairingEnergy.put("CUGA", -2.08);
		basepairingEnergy.put("AGUC", -2.08);
		basepairingEnergy.put("CAGU", -2.11);
		basepairingEnergy.put("UGAC", -2.11);
		basepairingEnergy.put("GUCA", -2.24);
		basepairingEnergy.put("ACUG", -2.24);
		basepairingEnergy.put("GACU", -2.35);
		basepairingEnergy.put("UCAG", -2.35);
		basepairingEnergy.put("CGGC", -2.36);
		basepairingEnergy.put("GGCC", -3.26);
		basepairingEnergy.put("CCGG", -3.26);
		basepairingEnergy.put("GCCG", -3.42);
		
		basepairingEnergy.put("AGUU", -0.55);
		basepairingEnergy.put("UUGA", -0.55);
		basepairingEnergy.put("AUUG", -1.36);
		basepairingEnergy.put("GUUA", -1.36);
		basepairingEnergy.put("CGGU", -1.41);
		basepairingEnergy.put("UGGC", -1.41);
		basepairingEnergy.put("CUGG", -2.11);
		basepairingEnergy.put("GGUC", -2.11);
		basepairingEnergy.put("GGCU", -1.53);
		basepairingEnergy.put("UCGG", -1.53);
		basepairingEnergy.put("GUCG", -2.51);
		basepairingEnergy.put("GCUG", -2.51);
		basepairingEnergy.put("GAUU", -1.27);
		basepairingEnergy.put("UUAG", -1.27);
		basepairingEnergy.put("GGUU", -0.50);
		basepairingEnergy.put("UUGG", -0.50);
		basepairingEnergy.put("GUUG", +1.29);
		basepairingEnergy.put("UGAU", -1.00);
		basepairingEnergy.put("UAGU", -1.00);
		basepairingEnergy.put("UGGU", +0.30);




		// RNA-DNA
		// Wu, Peng, Shu‐ichi Nakano, and Naoki Sugimoto. "Temperature dependence of thermodynamic properties for DNA/DNA and RNA/DNA duplex formation." The FEBS Journal 269.12 (2002): 2821-2830.
		basepairingEnergy.put("AAdTdT", -1.00);
		basepairingEnergy.put("ACdTdG", -2.10);
		basepairingEnergy.put("AGdTdC", -1.80);
		basepairingEnergy.put("AUdTdA", -0.90);
		basepairingEnergy.put("CAdGdT", -0.90);
		basepairingEnergy.put("CCdGdG", -2.10);
		basepairingEnergy.put("CGdGdC", -1.70);
		basepairingEnergy.put("CUdGdA", -0.90);
		basepairingEnergy.put("GAdCdT", -1.30);
		basepairingEnergy.put("GCdCdG", -2.70);
		basepairingEnergy.put("GGdCdC", -2.90);
		basepairingEnergy.put("GUdCdA", -1.10);
		basepairingEnergy.put("UAdAdT", -0.60);
		basepairingEnergy.put("UCdAdG", -1.50);
		basepairingEnergy.put("UGdAdC", -1.60);
		basepairingEnergy.put("UUdAdA", -0.20);
		
		basepairingEnergy.put("dTdTAA", -1.00);
		basepairingEnergy.put("dGdTCA", -2.10);
		basepairingEnergy.put("dCdTGA", -1.80);
		basepairingEnergy.put("dAdTUA", -0.90);
		basepairingEnergy.put("dTdGAC", -0.90);
		basepairingEnergy.put("dGdGCC", -2.10);
		basepairingEnergy.put("dCdGGC", -1.70);
		basepairingEnergy.put("dAdGUC", -0.90);
		basepairingEnergy.put("dTdCAG", -1.30);
		basepairingEnergy.put("dGdCCG", -2.70);
		basepairingEnergy.put("dCdCGG", -2.90);
		basepairingEnergy.put("dAdCUG", -1.10);
		basepairingEnergy.put("dTdAAU", -0.60);
		basepairingEnergy.put("dGdACU", -1.50);
		basepairingEnergy.put("dCdAGU", -1.60);
		basepairingEnergy.put("dAdAUU", -0.20);
		
		
		// DNA-DNA
		basepairingEnergy.put("dAdAdTdT", -1.00);
		basepairingEnergy.put("dTdTdAdA", -1.00);
		basepairingEnergy.put("dAdTdTdA", -0.88);
		basepairingEnergy.put("dTdAdAdT", -0.58);
		basepairingEnergy.put("dCdTdGdA", -1.28);
		basepairingEnergy.put("dAdGdTdC", -1.28);
		basepairingEnergy.put("dCdAdGdT", -1.45);
		basepairingEnergy.put("dTdGdAdC", -1.45);
		basepairingEnergy.put("dGdTdCdA", -1.44);
		basepairingEnergy.put("dAdCdTdG", -1.44);
		basepairingEnergy.put("dGdAdCdT", -1.30);
		basepairingEnergy.put("dTdCdAdG", -1.30);
		basepairingEnergy.put("dCdGdGdC", -2.17);
		basepairingEnergy.put("dGdGdCdC", -1.84);
		basepairingEnergy.put("dCdCdGdG", -1.84);
		basepairingEnergy.put("dGdCdCdG", -2.24);

		
		
	}
	
	
	
	
	
	
}
