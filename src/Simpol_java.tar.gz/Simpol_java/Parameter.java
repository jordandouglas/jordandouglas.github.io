import java.util.HashMap;

import org.apache.commons.math3.distribution.AbstractRealDistribution;
import org.apache.commons.math3.distribution.ExponentialDistribution;
import org.apache.commons.math3.distribution.GammaDistribution;
import org.apache.commons.math3.distribution.LogNormalDistribution;
import org.apache.commons.math3.distribution.NormalDistribution;
import org.apache.commons.math3.distribution.UniformRealDistribution;

public class Parameter {

	private String id = "";
	private String distributionName = "Fixed"; 
	private AbstractRealDistribution distribution = null;
	private double val = 0;
	
	
	private HashMap<String, Double> distributionParameters = new HashMap<String, Double>();
	private String zeroTruncated = "false";
	private boolean integer = false;
	
	public Parameter(String id, boolean integer, String zeroTruncated){
		this.id = id;
		this.integer = integer;
		this.zeroTruncated = zeroTruncated;
		
		this.distributionParameters.put("fixedDistnVal", 1.0);
		this.distributionParameters.put("uniformDistnUpperVal", 1.0);
		this.distributionParameters.put("uniformDistnLowerVal", 0.0);
		this.distributionParameters.put("lognormalMeanVal", 0.0);
		this.distributionParameters.put("lognormalSdVal", 1.0);
		this.distributionParameters.put("normalMeanVal", 0.0);
		this.distributionParameters.put("normalSdVal", 1.0);
		this.distributionParameters.put("gammaRateVal", 1.0);
		this.distributionParameters.put("gammaShapeVal", 1.0);
		this.distributionParameters.put("exponentialDistnVal", 1.0);
		this.distributionParameters.put("poissonRateVal", 1.0);
		
	}
	
	
	
	public String getID(){
		return this.id;
	}
	
	
	public double getVal(){
		return this.val;
	}
	
	
	// Samples a value for this parameter from its prior distribution. Mutates its value and returns the new one.
	public double sample(){
		
		if (this.distribution == null){
			this.val = this.distributionParameters.get("fixedDistnVal");
		}
		else{
			this.val = this.distribution.sample();
		}
		return this.val;
		
	}
	
	
	// Makes a proposal and changes the value of this parameter 
	public double makeProposal(){
		
		
		if (this.distribution == null){
			this.val = this.distributionParameters.get("fixedDistnVal");
		}
		else{
			
			// Generate a heavy tailed distribution random variable.
			// Using the algorithm in section 8.3 of https://arxiv.org/pdf/1606.03757.pdf
			double a = new NormalDistribution(0, 1).sample();
			double b = new UniformRealDistribution(0, 1).sample();
			double t = a / Math.sqrt(-Math.log(b));
			double n = new NormalDistribution(0, 1).sample();
			double x = Math.pow(10, 1.5 - 3*Math.abs(t)) * n;
			
			double stepSize = 0;
			double newVal = this.val;
			switch(this.distributionName){
			
			case "Uniform":

				// Wrap the value so that it bounces back into the right range
				stepSize = this.distributionParameters.get("uniformDistnUpperVal") - this.distributionParameters.get("uniformDistnLowerVal");
				newVal = this.val + x * stepSize;
				newVal = wrap(newVal,  this.distributionParameters.get("uniformDistnLowerVal"),  this.distributionParameters.get("uniformDistnUpperVal"));
				this.val = newVal;
				break;
				
				
			case "Normal":

				// Use the standard deviation as the step size
				stepSize =  this.distributionParameters.get("normalSdVal");
				newVal = this.val + x * stepSize;
				this.val = newVal;
				break;
 
				
			case "Lognormal":
				
				// Use the standard deviation of the normal as the step size, and perform the step in normal space then transform back into a lognormal
				stepSize = this.distributionParameters.get("lognormalSdVal");
				newVal = Math.exp(Math.log(this.val) + x * stepSize);
				this.val = newVal;
				break;
				
				
			// TODO: gamma, exponential, poisson
				
				
			
			}
			
			
		}
		
		
		return this.val;
		
	}
	
	
	public double getLogPrior(){
		
		
		double logPriorProbability = 0;
		switch (this.distributionName){

		case "Uniform":
			if (this.val < this.distributionParameters.get("uniformDistnLowerVal") || this.val > this.distributionParameters.get("uniformDistnUpperVal")) logPriorProbability = -Settings.INFINITY;
			else logPriorProbability = Math.log( 1 / (this.distributionParameters.get("uniformDistnUpperVal") - this.distributionParameters.get("uniformDistnLowerVal")) );
			break;


		case "Normal":
			//console.log(paramID, "log dnorm(", val, ",", mu, ",", sd, ") = ", Math.log( 1 / (Math.sqrt(2 * Math.PI * sd * sd)) * Math.exp(-(val-mu) * (val-mu) / (2 * sd * sd)) ));
			logPriorProbability = Math.log( 1 / (Math.sqrt(2 * Math.PI * this.distributionParameters.get("normalSdVal") * this.distributionParameters.get("normalSdVal"))) * Math.exp(-(val-this.distributionParameters.get("normalMeanVal")) * (val-this.distributionParameters.get("normalMeanVal")) / (2 * this.distributionParameters.get("normalSdVal") * this.distributionParameters.get("normalSdVal"))) );
			break;


		case "Lognormal":
			if (this.val <= 0) logPriorProbability = -Settings.INFINITY;
			else {
				double logval = Math.log(this.val); // Convert into normal space to calculate prior
				logPriorProbability = Math.log( 1 / (Math.sqrt(2 * Math.PI * this.distributionParameters.get("lognormalSdVal") * this.distributionParameters.get("lognormalSdVal"))) * Math.exp(-(logval-this.distributionParameters.get("lognormalMeanVal")) * (logval-this.distributionParameters.get("lognormalMeanVal")) / (2 * this.distributionParameters.get("lognormalSdVal") * this.distributionParameters.get("lognormalSdVal"))) );
			}
			break;


		case "Exponential":
			if (this.val <= 0) logPriorProbability = -Settings.INFINITY;
			else logPriorProbability = Math.log(this.distributionParameters.get("exponentialDistnVal") * Math.exp(-this.distributionParameters.get("exponentialDistnVal") * val));
			break;

			
		default:
			logPriorProbability = 0;
			break;

		// TODO: gamma, poisson

		}

		return logPriorProbability;
		
	}
	
	
	private double wrap(double x, double a, double b){
		return (x - a)%(b - a) + a;
	}

	
	
	public void updateDistribution(){
		
		switch(this.distributionName){
		
		
		
		case "Uniform":
			this.distribution = new UniformRealDistribution(this.distributionParameters.get("uniformDistnLowerVal"), this.distributionParameters.get("uniformDistnUpperVal"));
			break;
		
		case "Normal":
			this.distribution = new NormalDistribution(this.distributionParameters.get("normalMeanVal"), this.distributionParameters.get("normalSdVal"));
			break;
			
		case "Lognormal":
			this.distribution = new LogNormalDistribution(this.distributionParameters.get("lognormalMeanVal"), this.distributionParameters.get("lognormalSdVal"));
			break;
			
		case "Exponential":
			this.distribution = new ExponentialDistribution(this.distributionParameters.get("exponentialDistnVal"));
			break;
			
		case "Gamma":
			this.distribution = new GammaDistribution(this.distributionParameters.get("gammaRateVal"), this.distributionParameters.get("gammaShapeVal"));
			break;
			
		default:
			// TODO poisson, discrete uniform
			this.distribution = null;
			break;
		
		}
		
		
	}
	
	
	public Parameter setPriorDistribution(String distributionName){
		this.distributionName = distributionName;
		updateDistribution();
		
		return this;
	}
	
	
	public Parameter clone(){
		
		Parameter copy = new Parameter(this.id, this.integer, this.zeroTruncated);
		copy.distributionName = this.distributionName;
		copy.distributionParameters = (HashMap<String, Double>) this.distributionParameters.clone();
		copy.updateDistribution();
		copy.sample();
		return copy;
	}
	
	public void print(){
		System.out.print(this.id + " = " + this.val + " " + ", distribution " + this.distributionName + " ");
		System.out.println(this.distributionParameters.toString());
	}
	
	
	public Parameter setDistributionParameter(String name, double value){
		if (this.distributionParameters.get(name) == null) return this;
		this.distributionParameters.put(name, value);
		return this;
	}
	
	
	public double getDistributionParameter(String name){
		return this.distributionParameters.get(name);
	}



	public void setValue(double val) {
		this.val = val;
	}
	
	

}
