import java.util.ArrayList;

public class Model {
	
	private int id = -1;
	private double modelPrior = 0;
	private ArrayList<Parameter> parameters = null;
	private boolean allowBacktracking = false;
	private boolean allowHypertranslocation = false;
	private boolean allowInactivation = false;
	private boolean allowBacktrackWithoutInactivation = false;
	private boolean deactivateUponMisincorporation = false;
	private boolean allowGeometricCatalysis = false;
	private boolean allowmRNAfolding = false;
	private boolean allowMisincorporation = false;
	private boolean useFourNTPconcentrations = false;
	private boolean assumeBindingEquilibrium = true;
	private boolean assumeTranslocationEquilibrium = false;
	private String currentTranslocationModel = "";
	private int NTPbindingNParams = 2;
	
	
	
	public Model(){
		this.initParameters();
	}
	
	
	public Model(Model toClone){
		
		//this.initParameters();
		this.setParameters(toClone.getParameterClone());
		this.modelPrior = toClone.modelPrior;
		this.allowBacktracking = toClone.allowBacktracking;
		this.allowHypertranslocation = toClone.allowHypertranslocation;
		this.allowInactivation = toClone.allowInactivation;
		this.allowBacktrackWithoutInactivation = toClone.allowBacktrackWithoutInactivation;
		this.deactivateUponMisincorporation = toClone.deactivateUponMisincorporation;
		this.allowGeometricCatalysis = toClone.allowGeometricCatalysis;
		this.allowmRNAfolding = toClone.allowmRNAfolding;
		this.allowMisincorporation = toClone.allowMisincorporation;
		this.useFourNTPconcentrations = toClone.useFourNTPconcentrations;
		this.assumeBindingEquilibrium = toClone.assumeBindingEquilibrium;
		this.assumeTranslocationEquilibrium = toClone.assumeTranslocationEquilibrium;
		this.currentTranslocationModel = toClone.currentTranslocationModel;
		this.NTPbindingNParams = toClone.NTPbindingNParams;
		
		
	}
	
	
	
	public void setID(int id){
		this.id = id;
	}
	
	public int getID(){
		return this.id;
	}
	
	public void setModelPrior(double modelPrior){
		this.modelPrior = modelPrior; // Log prior probability of this model (without accounting for parameters)
	}
	
	public double getModelPrior() {
		return this.modelPrior;
	}
	
	
	
	// Returns the log prior probability of this model and all its parameters
	public double getLogPrior(){
		
		double logPrior = this.modelPrior;
		for (Parameter p : this.parameters){
			
			if (logPrior <= Settings.INFINITY) break;
			logPrior += p.getLogPrior();
			
		}
		return logPrior;
	}
	
	
	
	// Create the parameters used by this models
	public void initParameters(){
		
		this.parameters = new ArrayList<Parameter>();
		this.parameters.add(new Parameter("NTPconc", false, "inclusive"));
		this.parameters.add(new Parameter("ATPconc", false, "inclusive"));
		this.parameters.add(new Parameter("CTPconc", false, "inclusive"));
		this.parameters.add(new Parameter("GTPconc", false, "inclusive"));
		this.parameters.add(new Parameter("UTPconc", false, "inclusive"));
		this.parameters.add(new Parameter("FAssist", false, "false"));
		
		this.parameters.add(new Parameter("hybridLen", true, "exclusive"));
		this.parameters.add(new Parameter("bubbleLeft", true, "exclusive"));
		this.parameters.add(new Parameter("bubbleRight", true, "exclusive"));
		
		this.parameters.add(new Parameter("GDagSlide", false, "false"));
		this.parameters.add(new Parameter("DGPost", false, "false"));
		this.parameters.add(new Parameter("DGHyperDag", false, "false"));
		this.parameters.add(new Parameter("barrierPos", false, "exclusive"));
		
		
		this.parameters.add(new Parameter("kCat", false, "inclusive"));
		this.parameters.add(new Parameter("kCat_ATP", false, "inclusive"));
		this.parameters.add(new Parameter("kCat_CTP", false, "inclusive"));
		this.parameters.add(new Parameter("kCat_GTP", false, "inclusive"));
		this.parameters.add(new Parameter("kCat_UTP", false, "inclusive"));
		
		this.parameters.add(new Parameter("Kdiss", false, "exclusive"));
		this.parameters.add(new Parameter("Kdiss_ATP", false, "exclusive"));
		this.parameters.add(new Parameter("Kdiss_CTP", false, "exclusive"));
		this.parameters.add(new Parameter("Kdiss_GTP", false, "exclusive"));
		this.parameters.add(new Parameter("Kdiss_UTP", false, "exclusive"));
		
		this.parameters.add(new Parameter("RateBind", false, "inclusive"));
		
		this.parameters.add(new Parameter("nbpToFold", true, "exclusive"));
		this.parameters.add(new Parameter("arrestTime", false, "inclusive"));
		
	}
	
	
	public Parameter getParameter(String paramID){
		for (int i = 0; i < this.parameters.size(); i ++){
			if (this.parameters.get(i).getID().equals(paramID)) return this.parameters.get(i);
		}
		return null;
	}
	
	
	
	public void print(){
		
		System.out.println("\n---Model" + this.id + "---");
		System.out.println("modelPrior = " + this.modelPrior);
		System.out.println("totalPrior = " + this.getLogPrior());
		System.out.println("allowBacktracking = " + allowBacktracking);
		System.out.println("allowHypertranslocation = " + allowHypertranslocation);
		System.out.println("allowInactivation = " + allowInactivation);
		System.out.println("allowBacktrackWithoutInactivation = " + allowBacktrackWithoutInactivation);
		System.out.println("deactivateUponMisincorporation = " + deactivateUponMisincorporation);
		System.out.println("allowGeometricCatalysis = " + allowGeometricCatalysis);
		System.out.println("allowmRNAfolding = " + allowmRNAfolding);
		System.out.println("allowMisincorporation = " + allowMisincorporation);
		System.out.println("useFourNTPconcentrations = " + useFourNTPconcentrations);
		System.out.println("NTPbindingNParams = " + NTPbindingNParams);
		System.out.println("currentTranslocationModel = " + currentTranslocationModel);
		System.out.println("assumeBindingEquilibrium = " + assumeBindingEquilibrium);
		System.out.println("assumeTranslocationEquilibrium = " + assumeTranslocationEquilibrium);
		
		for (int i = 0; i < this.parameters.size(); i ++){
			this.parameters.get(i).print();
		}
		
		System.out.println("-----------\n");
		
		
	}
	
	
	
	// Get and set the model settings
	public Model set_allowBacktracking(boolean val){
		this.allowBacktracking = val;
		return this;
	}
	public boolean get_allowBacktracking(){
		return this.allowBacktracking;
	}
	
	
	public Model set_allowHypertranslocation(boolean val){
		this.allowHypertranslocation = val;
		return this;
	}
	public boolean get_allowHypertranslocation(){
		return this.allowHypertranslocation;
	}
	
	
	public Model set_allowInactivation(boolean val){
		this.allowInactivation = val;
		return this;
	}
	public boolean get_allowInactivation(){
		return this.allowInactivation;
	}
	
	
	public Model set_allowBacktrackWithoutInactivation(boolean val){
		this.allowBacktrackWithoutInactivation = val;
		return this;
	}
	public boolean get_allowBacktrackWithoutInactivation(){
		return this.allowBacktrackWithoutInactivation;
	}
	
	
	public Model set_deactivateUponMisincorporation(boolean val){
		this.deactivateUponMisincorporation = val;
		return this;
	}
	public boolean get_deactivateUponMisincorporation(){
		return this.deactivateUponMisincorporation;
	}
	
	
	
	public Model set_allowGeometricCatalysis(boolean val){
		this.allowGeometricCatalysis = val;
		return this;
	}
	public boolean get_allowGeometricCatalysis(){
		return this.allowGeometricCatalysis;
	}
	
	
	public Model set_allowmRNAfolding(boolean val){
		this.allowmRNAfolding = val;
		return this;
	}
	public boolean get_allowmRNAfolding(){
		return this.allowmRNAfolding;
	}
	
	public Model set_allowMisincorporation(boolean val){
		this.allowMisincorporation = val;
		return this;
	}
	public boolean get_allowMisincorporation(){
		return this.allowMisincorporation;
	}
	
	
	public Model set_useFourNTPconcentrations(boolean val){
		this.useFourNTPconcentrations = val;
		return this;
	}
	public boolean get_useFourNTPconcentrations(){
		return this.useFourNTPconcentrations;
	}
	
	
	public Model set_assumeBindingEquilibrium(boolean val){
		this.assumeBindingEquilibrium = val;
		return this;
	}
	public boolean get_assumeBindingEquilibrium(){
		return this.assumeBindingEquilibrium;
	}
	
	
	public Model set_assumeTranslocationEquilibrium(boolean val){
		this.assumeTranslocationEquilibrium = val;
		return this;
	}
	public boolean get_assumeTranslocationEquilibrium(){
		return this.assumeTranslocationEquilibrium;
	}
	
	
	public Model set_currentTranslocationModel(String val){
		this.currentTranslocationModel = val;
		return this;
	}
	public String get_currentTranslocationModel(){
		return this.currentTranslocationModel;
	}
	
	
	public Model set_NTPbindingNParams(int val){
		this.NTPbindingNParams = val;
		return this;
	}
	public int get_NTPbindingNParams(){
		return this.NTPbindingNParams;
	}


	public ArrayList<Parameter> getParameterClone() {
		ArrayList<Parameter> copy = new ArrayList<Parameter>();
		for (int i = 0; i < this.parameters.size(); i ++){
			copy.add(this.parameters.get(i).clone());
		}
		return copy;
	}
	
	
	public void setParameters(ArrayList<Parameter> params) {
		this.parameters = params;
	}



	public void sample() {
		for (Parameter p : parameters){
			p.sample();
		}
		
	}




	
	
}
