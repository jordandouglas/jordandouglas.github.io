
public class TranslocationRatesCache {

	
	private static double[][][] translocationRateTable;
	private static double[][] backtrackRateTable;
	
	
	
	
	

	public static double[] getTranslocationRates(CompressedState state){
	
	
		int h = (int)Settings.currentModel.getParameter("hybridLen").getVal();
		
		
		
		// Polymerase is not backtracked. Use regular translocation table
		if (state.get_mRNAPosInActiveSite() > -2){
			
			
			int rowNum = state.get_nascentLength() - (h-1);
			int colNum = state.get_mRNAPosInActiveSite() + 1;
			
			
			double[] rates = translocationRateTable[rowNum][colNum];
			double GDagRateModifier = Math.exp(-Settings.currentModel.getParameter("GDagSlide").getVal());
			double forceGradientFwd = Math.exp(( Settings.currentModel.getParameter("FAssist").getVal() * 1e-12 * (Settings.currentModel.getParameter("barrierPos").getVal()) * 1e-10) / (1.380649e-23 * 310));
			double forceGradientBck = Math.exp((-Settings.currentModel.getParameter("FAssist").getVal() * 1e-12 * (3.4-Settings.currentModel.getParameter("barrierPos").getVal()) * 1e-10) / (1.380649e-23 * 310));
			double DGPostModifier = state.get_mRNAPosInActiveSite() == 1 ? Math.exp(Settings.currentModel.getParameter("DGPost").getVal()) : 1;
	
			
		
	
			
			
			double hypertranslocationGradientForward = 1; // Modify the rate of hypertranslocating forwards
			double hypertranslocationGradientBackwards = 1; // Modify the rate of translocating backwards when in a hypertranslocated state
			if (Settings.currentModel.get_allowHypertranslocation()){
				//if (compactState[1] > 0) hypertranslocationGradientForward = Math.exp(-PARAMS_JS.PHYSICAL_PARAMETERS["DGHyperDag"]["val"] * 0.5);
				//if (compactState[1] > 1) hypertranslocationGradientBackwards = Math.exp(PARAMS_JS.PHYSICAL_PARAMETERS["DGHyperDag"]["val"] * 0.5);
			}
	
	
			if (rates != null) {
				return new double[] {rates[0] * DGPostModifier * GDagRateModifier * hypertranslocationGradientBackwards * forceGradientBck, rates[1] * DGPostModifier * GDagRateModifier * hypertranslocationGradientForward * forceGradientFwd};
			}
	
			
			// Temporarily set state to inactive so it lets us backtrack
			//int temp = compactState[3];
			//compactState[3] = false;
			
			// If rates are not in table then add them and return them
			double kbck = state.calculateBackwardRate(false); // Important to include false or will end up in infinite loop
			double kfwd = state.calculateForwardRate(false);
			translocationRateTable[rowNum][colNum] = new double[] {kbck, kfwd};
			return new double[] {kbck * DGPostModifier * GDagRateModifier * hypertranslocationGradientBackwards * forceGradientBck, kfwd * DGPostModifier * GDagRateModifier * hypertranslocationGradientForward * forceGradientFwd};
			
			
		}
		
		
		// Polymerase is backtracked. Use backtracking table
		else{
			
			
			
			
			int rightHybridBase = state.get_mRNAPosInActiveSite() + state.get_nascentLength();
			int leftHybridBase = rightHybridBase + 1 - h;
			int indexNum = leftHybridBase - 1;
	
			double[] rates = backtrackRateTable[indexNum];
			double GDagRateModifier = Math.exp(-Settings.currentModel.getParameter("GDagSlide").getVal());
			double forceGradientFwd = Math.exp(( Settings.currentModel.getParameter("FAssist").getVal() * 1e-12 * (Settings.currentModel.getParameter("barrierPos").getVal()) * 1e-10) / (1.380649e-23 * 310));
			double forceGradientBck = Math.exp((-Settings.currentModel.getParameter("FAssist").getVal() * 1e-12 * (3.4-Settings.currentModel.getParameter("barrierPos").getVal()) * 1e-10) / (1.380649e-23 * 310));
	
			
			if (rates != null) {
				return new double[] {rates[0] * GDagRateModifier * forceGradientBck, rates[1] * GDagRateModifier * forceGradientFwd};
			}
			
			
			// If rates are not in table then add them and return them
			double kbck = state.calculateBackwardRate(false); // Important to include false or will end up in infinite loop
			double kfwd = state.calculateForwardRate(false);
			backtrackRateTable[indexNum] = new double[] {kbck, kfwd};
			return new double[] {kbck * GDagRateModifier * forceGradientBck, kfwd * GDagRateModifier * forceGradientFwd};
			
			
		}
		

	
	}

	
	
	
	public static void buildTranslocationRateTable(){
		
		
		// Don't calculate all at once, only calculating for active site positions 0 and 1. Simulation caches hypertranslocated rates as it goes. 
		// Most states are never sampled. Otherwise far too slow to load for n > 300
		
		
		// Rows are the lengths of the mRNA and cols are the position of the active site (minimum value -1, maximum value h-1). Backtracking rates are found in the backtracking table
		// Each entry is a tuple (kbck, kfwd)
		// There are n - h rows (n is total number of bases, h is hybrid length)
		// There are l + 1 entries in each row, where l is the length of the nascent strand in the row
		
		int h = (int)Settings.currentModel.getParameter("hybridLen").getVal();
		int nLengths = Settings.seq.length() - h + 1;
		int nPositions = h + 1;
		if (nLengths <= 0) return;
		
		translocationRateTable = new double[nLengths][][];
		for(int nascentLen = h-1; nascentLen < Settings.seq.length(); nascentLen ++){
			
			int rowNum = nascentLen - (h-1);
			
			translocationRateTable[rowNum] = new double[nPositions][];
			
			for (int activeSitePos = -1; activeSitePos <= h-1; activeSitePos ++){
				int colNum = activeSitePos + 1;
				translocationRateTable[rowNum][colNum] = null; // Will leave it empty and add values only as they are needed
			}
			
		}
		
		
	}
	
	
	
	
public static void buildBacktrackRateTable(){
		
		
		// Once the polymerase has entered state -2 (ie backtracked by 2 positions) then all backtracking rates 
		// are the same per position across different nascent strand lengths. The bases added onto the nascent strand
		// which are coming out of the NTP pore don't matter. This assumption would no longer hold if we started
		// folding the 3' end of the nascent strand
		
		int h = (int)Settings.currentModel.getParameter("hybridLen").getVal();
		if (Settings.seq.length() - h - 1 < 0) return;
		backtrackRateTable = new double[Settings.seq.length() - h - 1][];
		
		
		for (int leftHybridBase = 1; leftHybridBase <= backtrackRateTable.length; leftHybridBase ++){
			int indexNum = leftHybridBase - 1;
			backtrackRateTable[indexNum] = null; // Will leave it empty and add values only as they are needed
		}
		
	}
	
	
	
	
}
