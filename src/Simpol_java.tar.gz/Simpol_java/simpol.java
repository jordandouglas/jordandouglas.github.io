import java.io.IOException;
import java.util.Timer;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

public class simpol {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		System.out.println("Hello there");
		
		long startTime = System.nanoTime();
		
		
		//String arg1 = "/home/jdou557/Documents/Sequences/December2017/Models12_chi8/test.xml";
		String arg1 = "benchmark.xml";
		
		int arg2 = 1; // nthreads
		boolean arg3 = false; // ABC
		
		
		XMLparser.parse(arg1);
		Settings.nthreads = arg2;
		Settings.complementSeq = Settings.complementSequence(Settings.seq, Settings.TemplateType.substring(2).equals("RNA"));
		FreeEnergy.init();
		
		
		
		// Initialise the translocation rate cache
		TranslocationRatesCache.buildTranslocationRateTable();
		TranslocationRatesCache.buildBacktrackRateTable();
		
		// Perform ABC
		if (arg3){
			
			
			
			
		}
		
		// Just simulate
		else{
			Simulator sim = new Simulator();
			sim.perform_N_Trials(Settings.ntrials_sim, new CompressedState(true));
			
			
		}
		
		
		
		long stopTime = System.nanoTime();
		double timeElapsed = Settings.roundToSF(1e-9 * (stopTime - startTime), 3);
		System.out.println("Total time elapsed: " + timeElapsed + "s");
		
		
		
	}

}
