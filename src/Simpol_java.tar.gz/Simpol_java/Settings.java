import java.util.ArrayList;

import org.apache.commons.math3.distribution.UniformIntegerDistribution;

public class Settings {


	public static final double INFINITY = 10000000.0;
	public static final double RT = 0.6156;
	public static final double kBT = 1.380649e-23 * 310;
	public static final double preExp = 1e6;	
	
	public static int nthreads = 1;
	public static int ntrials_sim;
	
	// Models to compare
	public static ArrayList<Model> models = new ArrayList<Model>();
	public static Model currentModel = null;
	
	
	// Sequence settings
	public static String seqID = "";
	public static String seq = "";
	public static String complementSeq = "";
	public static String TemplateType = "";
	public static String PrimerType = "";
	
	
	// ABC settings
	public static String inferenceMethod = "";
	public static int ntrials_MCMC = 1000000;
	public static int testsPerData = 1;
	public static double chiSqthreshold_min;
	public static double chiSqthreshold_0;
	public static double chiSqthreshold_gamma;
	public static double burnin;
	public static int logEvery;

	
	// Experimental observations
	public static ArrayList<ExperimentalData> experiments = new ArrayList<ExperimentalData>();

	
	
	
	
	public static void addModel(Model model){
		models.add(model);
	}
	
	
	
	public static String complementSequence(String orig, boolean toRNA){
		
		orig = orig.toUpperCase();
		String complement = "";
		for (int i = 0; i < orig.length(); i ++){
		
			String base = orig.substring(i, i+1);
			complement += base.equals("C") ? "G" : base.equals("G") ? "C" : (base.equals("U") || base.equals("T")) ? "A" : 
				(base.equals("A") && !toRNA) ? "T" : 
				(base.equals("A") && toRNA) ? "U" :"X";
		}
		
		return complement;
		
	}
	
	
	public static void sampleParameters(){
		
		for (Model m : models){
			m.sample();
		}
		
		// Sample a model
		int runif = new UniformIntegerDistribution(0, models.size()-1).sample();
		currentModel = models.get(runif);
	}
	
	
	public static void printSettings(){
		
		
		System.out.println("\n---Settings---");
		System.out.println("seqID = " + seqID + "; TemplateType = " + TemplateType + "; PrimerType = " + PrimerType);
		System.out.println("seq = " + seq);
		System.out.println("inferenceMethod = " + inferenceMethod + "; ntrials_MCMC = " + ntrials_MCMC + "; testsPerData = " + testsPerData  + "; logEvery = " + logEvery + "; chiSqthreshold_min = " + chiSqthreshold_min  + "; chiSqthreshold_0 = " + chiSqthreshold_0  + "; chiSqthreshold_gamma = " + chiSqthreshold_gamma  + "; burnin = " + burnin);
		for (int i = 0; i < models.size(); i ++){
			models.get(i).print();
		}
		for (int i = 0; i < experiments.size(); i ++){
			experiments.get(i).print();
		}
		System.out.println("--------------\n");
		
	}
	
	
	
	public static double log10(double val){
		if (val == 0) return 0;
		return Math.log(val) / Math.log(10);
	}
	
	
	public static double roundToSF(double val, int sf){
	
	int magnitude = (int)Math.floor(log10(val));

	double num = val * Math.pow(10, sf-magnitude);
	num = Math.round(num);
	num = num * Math.pow(10, magnitude-sf);
	
	// Sometimes this picks up a trailing .00000000001 which we want to remove

	int expectedStringLength = 0;
	if (magnitude >= 0) expectedStringLength = magnitude >= sf ? magnitude+1 : sf+2; // Add 1 for the decimal point
	else expectedStringLength = 2 -magnitude + sf;
	if (num < 0) expectedStringLength++; // Also need the negative symbol

	String temp = ("" + num);
	num = Double.parseDouble(temp.substring(0, Math.min(temp.length(), expectedStringLength+1)));
	
	return num;
		
}


	
	
	
	
}
