import java.util.ArrayList;

public class ExperimentalData {

	private int id = 0;
	private String dataType = "";
	private ArrayList<Double> xVals = new ArrayList<Double>();
	private ArrayList<Double> yVelocities = new ArrayList<Double>();
	
	private double[] NTPconcs = new double[4]; // Baseline NTP concentrations
	private double force = 0; // A constant force throughout all trials?


	public ExperimentalData(int id, String dataType){
		this.id = id;
		this.dataType = dataType;
	}
	
	
	public void addObservation(double x, double y){
		xVals.add(x);
		yVelocities.add(y);
	}
	
	public void setConcentrations(double ATP, double CTP, double GTP, double UTP){
		this.NTPconcs = new double[] { ATP, CTP, GTP, UTP };
	}
	
	public void setforce(double force){
		this.force = force;
	}
	
	
	public void print(){
		System.out.println("fit" + id + ", dataType=" + dataType + ", x = " + xVals.toString() + ", y = " + yVelocities.toString() + " [ATP]=" + NTPconcs[0] + " [CTP]=" + NTPconcs[1] + " [GTP]=" + NTPconcs[2] + " [UTP]=" + NTPconcs[3] + " force = " + force);
	}
	
	
}
