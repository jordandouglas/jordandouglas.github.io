


public class CompressedState {

	
	private String nascentSequence = "";
	private int mRNAPosInActiveSite = 0;
	private String boundNTP = "";
	private boolean terminated = false;
	
	
	public CompressedState(boolean init){
		if (init) this.setToInitialState();
	}
	
	
	
	public CompressedState clone(){
		CompressedState s = new CompressedState(false);
		s.nascentSequence = this.nascentSequence;
		s.mRNAPosInActiveSite = this.mRNAPosInActiveSite;
		s.boundNTP = this.boundNTP;
		s.terminated = this.terminated;
		return s;
	}
	
	
	public void setToInitialState(){
		
		// Reset the sequence
		this.nascentSequence = "";
		int sequenceLength = (int)(Settings.currentModel.getParameter("hybridLen").getVal()-1);
		for (int i = 0; i < sequenceLength; i ++){
			this.nascentSequence += Settings.complementSequence(Settings.seq.substring(i, i+1), Settings.PrimerType.substring(2).equals("RNA"));
		}
		
		this.mRNAPosInActiveSite = 0;
		this.boundNTP = "";
		this.terminated = false;
		
		
		// Transcribe a few bases forward to avoid left bubble effects
		this.transcribe(2 + Math.max(2, (int)Settings.currentModel.getParameter("bubbleLeft").getVal()));
		
	}
	
	public void print(){
		
		int bubblePrint = 10;
		
		if (!this.terminated){
		
			// Left bubble (template strand)
			int start = Math.max(0, this.get_nascentLength() - (int)(Settings.currentModel.getParameter("hybridLen").getVal()) - bubblePrint);
			int stop = Math.max(0, this.get_nascentLength() + this.mRNAPosInActiveSite - (int)(Settings.currentModel.getParameter("hybridLen").getVal()));
			System.out.println((start+1) + Settings.seq.substring(start, stop));
			
			// Hybrid (template side)
			start = stop;
			stop = this.get_nascentLength() + this.mRNAPosInActiveSite;
			System.out.printf("%" + (stop - start + (int)(Settings.currentModel.getParameter("hybridLen").getVal())) + "s\n", Settings.seq.substring(start, stop));
			
			
			// Hybrid (nascent side)
			stop = this.get_nascentLength();
			System.out.printf("%" + (stop - start + (int)(Settings.currentModel.getParameter("hybridLen").getVal())) + "s", this.nascentSequence.substring(start, stop));
			if (this.NTPbound()) System.out.print(this.boundNTP.toLowerCase());
			System.out.println("");
			
			
			// Left bubble (nascent strand)
			stop = start;
			start = Math.max(0, this.get_nascentLength() - (int)(Settings.currentModel.getParameter("hybridLen").getVal()) - bubblePrint);
			System.out.println((start+1) + this.nascentSequence.substring(start, stop));
			}
		
		System.out.println("[" + this.get_nascentLength() + ","  + this.mRNAPosInActiveSite + "," + this.NTPbound() + "," + this.terminated + "]\n");
		
	}
	
	
	public boolean isTerminated(){
		return this.terminated;
	}

	
	public boolean NTPbound(){
		return !this.boundNTP.equals("");
	}
	
	public int get_mRNAPosInActiveSite(){
		return this.mRNAPosInActiveSite;
	}
	
	public int get_nascentLength(){
		return this.nascentSequence.length();
	}
	
	public String get_NascentSequence(){
		return this.nascentSequence;
	}
	
	public int get_initialLength() {
		
		// Returns the length of the sequence when it was first created
		return (int)(Settings.currentModel.getParameter("hybridLen").getVal()-1) + 2 + Math.max(2, (int)Settings.currentModel.getParameter("bubbleLeft").getVal());
	}
	
	
	public int getLeftBaseNumber(){
		return this.get_nascentLength() + this.get_mRNAPosInActiveSite() + 1 - (int)Settings.currentModel.getParameter("hybridLen").getVal();
	}
	
	public int getRightBaseNumber(){
		return this.get_nascentLength() + this.get_mRNAPosInActiveSite();
	}
	
	
	
	
	
	
	public void transcribe(int N){
		
		
		
		// Ensure that active site is open and NTP is not bound
		if (this.NTPbound()) this.releaseNTP();
		for (int i = this.mRNAPosInActiveSite; i < 1; i ++){
			this.forward();
		}
		for (int i = this.mRNAPosInActiveSite; i > 1; i --){
			this.backward();
		}
		
		
		
		// Transcribe N bases
		for (int i = 0; i < N; i ++){
			this.bindNTP();
			this.bindNTP();
			this.forward();
		}
		
		
	}
	
	
	public CompressedState forward(){
		if (this.terminated) return this;
		if (!this.NTPbound()) this.mRNAPosInActiveSite ++; // Only move forward if NTP is not bound
		if (this.mRNAPosInActiveSite > Settings.currentModel.getParameter("hybridLen").getVal()-1 ||
			(this.mRNAPosInActiveSite <= 1 && this.mRNAPosInActiveSite + this.get_nascentLength() + 1 > Settings.seq.length())) this.terminated = true;
		
		return this;
	}
	
	public double calculateForwardRate(boolean lookupFirst){
		
		if (this.terminated || this.NTPbound()) return 0;
		if ( Settings.currentModel.get_assumeTranslocationEquilibrium() && this.mRNAPosInActiveSite == 0) return 0;
		
		// Lookup in table first or calculate it again?
		if (lookupFirst){
			double kFwd = TranslocationRatesCache.getTranslocationRates(this)[1];
			return kFwd;
		}
		
		
		double groundEnergy = this.calculateTranslocationFreeEnergy();
		double forwardHeight = this.calculateForwardTranslocationFreeEnergyBarrier();
		if (forwardHeight >= Settings.INFINITY) return 0;
		
		
		// Calculate rate
		return Settings.preExp * Math.exp(-(forwardHeight - groundEnergy));
		

	}
	
	
	public CompressedState backward(){
		if (this.terminated) return this;
		if (!this.NTPbound()) this.mRNAPosInActiveSite --; // Only move backwards if NTP is not bound
		return this;
	}
	
	
	public double calculateBackwardRate(boolean lookupFirst){
		
		if (this.terminated || this.NTPbound()) return 0;
		if ( Settings.currentModel.get_assumeTranslocationEquilibrium() && this.mRNAPosInActiveSite == 1) return 0;
		
		// Lookup in table first or calculate it again?
		if (lookupFirst){
			double kBck = TranslocationRatesCache.getTranslocationRates(this)[0];
			return kBck;
		}
		
		
		
		double groundEnergy = this.calculateTranslocationFreeEnergy();
		double backwardHeight = this.calculateBackwardTranslocationFreeEnergyBarrier();
		if (backwardHeight >= Settings.INFINITY) return 0;
		
		
		// Calculate rate
		return Settings.preExp * Math.exp(-(backwardHeight - groundEnergy));
		

	}
	
	
	public CompressedState bindNTP(){
		
		if (this.terminated) return this;
		
		// Bind NTP
		if (!this.NTPbound() && this.mRNAPosInActiveSite == 1){
			this.boundNTP = Settings.complementSequence(Settings.seq.substring(this.get_nascentLength(), this.get_nascentLength()+1), Settings.PrimerType.substring(2).equals("RNA"));
		}
		
		// Elongate
		else if (this.NTPbound() && this.mRNAPosInActiveSite == 1){
			this.nascentSequence += this.boundNTP;
			this.boundNTP = "";
			this.mRNAPosInActiveSite = 0;
		}
		
		return this;
		
	}
	
	
	public double calculateBindNTPrate(){
		
		if (this.terminated) return 0;
		
		
		// Bind NTP
		if (!this.NTPbound() && this.mRNAPosInActiveSite == 1){
			
			
			// If binding is at equilibrium return 0
			if (Settings.currentModel.get_assumeBindingEquilibrium()) return 0;
			
			
			// NTP concentration to use
			String toBind = Settings.complementSequence(Settings.seq.substring(this.get_nascentLength(), this.get_nascentLength()+1), Settings.PrimerType.substring(2).equals("RNA"));
			double NTPconcentration = 0;
			if (Settings.currentModel.get_useFourNTPconcentrations()){
				NTPconcentration = Settings.currentModel.getParameter(toBind + "TPconc").getVal();
			}
			else NTPconcentration = Settings.currentModel.getParameter("NTPconc").getVal();
			
			// Calculate the rate of binding
			return Settings.currentModel.getParameter("RateBind").getVal() * NTPconcentration;
			
		}
				
		// Elongate
		else if (this.NTPbound() && this.mRNAPosInActiveSite == 1){
			return Settings.currentModel.getParameter("kCat").getVal();
		}
				
		return 0;
				
		
	}
	
	
	public CompressedState releaseNTP(){
		
		if (this.terminated) return this;
		
		if (this.NTPbound()){
			this.boundNTP = "";
		}
		
		return this;
		
	}
	
	public double calculateReleaseNTPRate(){
		
		if (!this.NTPbound() || this.terminated || Settings.currentModel.get_assumeBindingEquilibrium()) return 0;
		return Settings.currentModel.getParameter("RateBind").getVal() * Settings.currentModel.getParameter("Kdiss").getVal(); 
		
	}
	
	
	public double calculateTranslocationFreeEnergy(){
		
		double freeEnergy = FreeEnergy.getFreeEnergyOfHybrid(this) - FreeEnergy.getFreeEnergyOfTranscriptionBubble(this);
		//System.out.println("hybrid " + FreeEnergy.getFreeEnergyOfHybrid(this) + " bubble " + FreeEnergy.getFreeEnergyOfTranscriptionBubble(this));
		
		return freeEnergy;
		
	}
	
	
	
	public double calculateForwardTranslocationFreeEnergyBarrier(){
		

		double barrierHeight = 0;
		

		// Check if hypertranslocation is permitted
		if (!Settings.currentModel.get_allowHypertranslocation() && this.mRNAPosInActiveSite >= 1){
			return Settings.INFINITY;
		}
 
		
		CompressedState stateAfterForwardtranslocation = this.clone().forward();
		
		// Midpoint model: free energy barrier is halfway between the two on either side
		if (Settings.currentModel.get_currentTranslocationModel().equals("midpointBarriers")){
			barrierHeight += (this.calculateTranslocationFreeEnergy() + stateAfterForwardtranslocation.calculateTranslocationFreeEnergy()) / 2;
		}

		else if (Settings.currentModel.get_currentTranslocationModel().equals("meltingBarriers") || Settings.currentModel.get_currentTranslocationModel().equals("sealingBarriers")){
			barrierHeight += FreeEnergy.getFreeEnergyOfIntermediateState(this, stateAfterForwardtranslocation);
			barrierHeight -= FreeEnergy.getFreeEnergyOfTranscriptionBubbleIntermediate(this, stateAfterForwardtranslocation); // Subtract the free energy which we would gain if the intermediate transcription bubble was sealed
		}
		
		
		
		// Assisting force
		if (Settings.currentModel.getParameter("FAssist").getVal() != 0){
			
			// Force x distance / kB T
			//barrierHeight += Settings.currentModel.getParameter("FAssist").getVal() * 1e-12 * (3.4e-10 - Settings.currentModel.getParameter("barrierPos").getVal() * 1e-10) / Settings.kBT;
		}
		
		
		return barrierHeight;
		
		
	}
	
	
	
	
	public double calculateBackwardTranslocationFreeEnergyBarrier(){
		
		
		double barrierHeight = 0;
		
		
		
		
		// Do not back translocate if it will cause the bubble to be open on the 3' end
		if (this.getLeftBaseNumber() - Settings.currentModel.getParameter("bubbleLeft").getVal() -1 <= 2){
			return Settings.INFINITY;
		}


		// Check if backtracking is permitted
		if (!Settings.currentModel.get_allowBacktracking() && this.mRNAPosInActiveSite <= 0){
			return Settings.INFINITY;
		}
 
		
		CompressedState stateAfterBacktranslocation = this.clone().backward();
		
		// Midpoint model: free energy barrier is halfway between the two on either side
		if (Settings.currentModel.get_currentTranslocationModel().equals("midpointBarriers")){
			barrierHeight += (this.calculateTranslocationFreeEnergy() + stateAfterBacktranslocation.calculateTranslocationFreeEnergy()) / 2;
		}

		else if (Settings.currentModel.get_currentTranslocationModel().equals("meltingBarriers") || Settings.currentModel.get_currentTranslocationModel().equals("sealingBarriers")){
			barrierHeight += FreeEnergy.getFreeEnergyOfIntermediateState(this, stateAfterBacktranslocation);
			barrierHeight -= FreeEnergy.getFreeEnergyOfTranscriptionBubbleIntermediate(this, stateAfterBacktranslocation); // Subtract the free energy which we would gain if the intermediate transcription bubble was sealed
		}
		
		
		
		// Assisting force
		if (Settings.currentModel.getParameter("FAssist").getVal() != 0){
			
			// Force x distance / kB T
			//barrierHeight += Settings.currentModel.getParameter("FAssist").getVal() * 1e-12 * (3.4e-10 - Settings.currentModel.getParameter("barrierPos").getVal() * 1e-10) / Settings.kBT;
		}
		
		
		
		return barrierHeight;
	}


	
	


	
	


	
	
}











