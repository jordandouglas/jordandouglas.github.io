import org.apache.commons.math3.distribution.ExponentialDistribution;
import org.apache.commons.math3.distribution.UniformRealDistribution;
import org.apache.commons.math3.random.MersenneTwister;

public class Simulator {

	
	//UniformRealDistribution distribution = new UniformRealDistribution(0, 1);
	MersenneTwister distribution = new MersenneTwister();
	
	
	public Simulator(){
		
		
	}
	
	
	public void perform_N_Trials(int N, CompressedState s) throws Exception{
		
		
		
		//for (int i = 0; i < 1e9; i++){
			//mt.nextDouble();
		//}
		
		
		//N = 10;
		
		//System.out.println("Model " + Settings.currentModel.getID());
		System.out.println("Performing " + N + " trials " + Settings.currentModel.getParameter("DGPost").getVal());
		s.print();
		//System.out.println(s.calculateForwardTranslocationFreeEnergyBarrier());
		
		
		
		
		double meanMeanVelocity = 0;
		for (int n = 1; n <= N; n ++){
			if (n == 1 || n % 10 == 0) System.out.println("Starting trial " + n);
			meanMeanVelocity += performSimulation(s.clone()) / N;
		}
		
		
		System.out.println("Mean velocity over " + N + " simulations = " + meanMeanVelocity);
		
	
	}
	
	private double rexp(double rate){
		//return new ExponentialDistribution(1/rate).sample();
		return -Math.log(distribution.nextDouble()) / rate;
	}
	
	
	
	private double performSimulation(CompressedState s) throws Exception{
		
		
		
		double timeElapsed = 0;
		int Niterations = 0;
		int maxIterations = (int)Settings.INFINITY;
		
		
		
		while(!s.isTerminated() && Niterations < maxIterations){
			
			Niterations++;
			
			
			// Geometric catalysis hack
			if (!Settings.currentModel.get_assumeBindingEquilibrium() && 
				((!Settings.currentModel.get_assumeTranslocationEquilibrium() && s.get_mRNAPosInActiveSite() == 1) ||  // If no translocation equilibrium and posttranslocated
				(Settings.currentModel.get_assumeTranslocationEquilibrium() && (s.get_mRNAPosInActiveSite() == 0 || s.get_mRNAPosInActiveSite() == 1))) && // OR equilibrium assumed and post/pretranslocated
				!s.NTPbound() && Settings.currentModel.get_allowGeometricCatalysis()) {
						
				
				timeElapsed += geometricSampling(s);
				
			}
			
			else {
			
				double[] rates = new double[] { s.calculateBackwardRate(true), s.calculateForwardRate(true), s.calculateReleaseNTPRate(), s.calculateBindNTPrate() };
				double rateSum = 0;
				for (int i = 0; i < rates.length; i ++) rateSum += rates[i];
				
				
				if (rateSum <= 0){
					System.out.println("No operations to apply");
					break;
				}
	 			
				
				// Generate a random number to determine which reaction to apply
				double runif = distribution.nextDouble() * rateSum;
				double cumsum = 0;
				int reactionToDo = -1;
				
				//System.out.println("runif " + runif + " rates " + rates[0] + "|" + rates[1] + "|" + rates[2] + "|" + rates[3]);
				
				for (int i = 0; i < rates.length; i ++){
					cumsum += rates[i];
					if (runif < cumsum) {
						reactionToDo = i;
						break;
					}
				}
				
				if (reactionToDo == -1) throw new Exception("Reaction sampled was -1");
				
				
				double reactionTime = rexp(rateSum);// new ExponentialDistribution(1/rateSum).sample(); // Random exponential
				
				
				timeElapsed += reactionTime;
				//System.out.println("sampled reaction " + reactionToDo  +", time elapsed = " + timeElapsed);
				
				// Apply the reaction
				executeAction(s, reactionToDo);
			}
			
			//s.print();
		}
		
		
		// Calculate mean velocity
		int distanceTravelled = s.get_nascentLength() - s.get_initialLength();
		double velocity = distanceTravelled / timeElapsed;
		//System.out.println("d = " + distanceTravelled + " t = " + timeElapsed);
		//System.out.println("v = " + velocity);
		
		return velocity;
		
		
	}
	
	
	
	
	private double geometricSampling(CompressedState s){
		
		if (s.NTPbound()) return 0;
		if (s.get_mRNAPosInActiveSite() != 0 && s.get_mRNAPosInActiveSite() != 1) return 0;
		
		//if (!(!Settings.currentModel.get_assumeTranslocationEquilibrium() && s.get_mRNAPosInActiveSite() == 1)) return;
		
		//if (!(Settings.currentModel.get_assumeTranslocationEquilibrium() && (s.get_mRNAPosInActiveSite() == 0 || s.get_mRNAPosInActiveSite() == 1))) return;
		
		//if (!FE_JS.ELONGATION_MODELS[FE_JS.currentElongationModel]["assumeBindingEquilibrium"] && 
		//		((!FE_JS.ELONGATION_MODELS[FE_JS.currentElongationModel]["assumeTranslocationEquilibrium"] && stateC[1] == 1) ||  // If no translocation equilibrium and posttranslocated
		//		(FE_JS.ELONGATION_MODELS[FE_JS.currentElongationModel]["assumeTranslocationEquilibrium"] && (stateC[1] == 0 || stateC[1] == 1))) && // OR equilibrium assumed and post/pretranslocated
		//		!stateC[2] && stateC[3] && FE_JS.ELONGATION_MODELS[FE_JS.currentElongationModel]["allowGeometricCatalysis"] && 
		//		FE_JS.ELONGATION_MODELS[FE_JS.currentElongationModel]["id"] == "simpleBrownian"){

		
		
		double kBck = s.calculateBackwardRate(true);
		double kFwd = s.calculateBackwardRate(true);
		double kRelease = s.calculateReleaseNTPRate();
		double kBind = s.calculateBindNTPrate();
		double kcat = Settings.currentModel.getParameter("kCat").getVal();
		double rateRelCat = kRelease + kcat;
		double rateBindRelease = kBind * kRelease / rateRelCat;

		//console.log("rateBindRelease", rateBindRelease);

		double rate = kBck + kFwd + kBind; // + kRelease


		// Keep sampling until it is NOT bind release
		double runif = distribution.nextDouble() * rate;
		double totalReactionTime = 0;
		while(runif < rateBindRelease){
			totalReactionTime += rexp(rate);// new ExponentialDistribution(1/rate).sample();  // Time taken to bind
			totalReactionTime += rexp(rateRelCat);// new ExponentialDistribution(1/rateRelCat).sample(); // Time taken to release
			runif = distribution.nextDouble() * rate;
		}


		// Choose next action uniformly
		kRelease = 0;
		boolean assumeTranslocationEquilibrium = false;
		double rateBindCat = assumeTranslocationEquilibrium ? kBind : kBind * kcat / rateRelCat;
		double[] rates = new double[] { kBck, kFwd, kRelease, rateBindCat };
		double sum = kBck + kFwd + kRelease + rateBindCat;
		runif = distribution.nextDouble() * sum;
		double cumsum = 0;
		int toDo = -1;
		for (int i = 0; i < rates.length; i ++){
			cumsum += rates[i];
			if (runif < cumsum) {
				toDo = i;
				break;
			}

		}
		totalReactionTime += rexp(sum);// new ExponentialDistribution(1/sum).sample();


		// If next action is bindcat then add the time for catalysis
		int[] actionsToDoList = new int[] { toDo };
		if (!assumeTranslocationEquilibrium && toDo == 3) {
			totalReactionTime += rexp(rateRelCat);// new ExponentialDistribution(1/rateRelCat).sample();
			actionsToDoList = new int[] { 3,3 };
		}
		
		
		
		for (int i = 0; i < actionsToDoList.length; i ++){
			executeAction(s, actionsToDoList[i]);
		}

		
		return totalReactionTime;
		
	}
	
	
	private void executeAction(CompressedState s, int reactionToDo){
		
		switch(reactionToDo){
			case 0: 
				s.backward();
				break;
			case 1:
				s.forward();
				break;
			case 2:
				s.releaseNTP();
				break;
			case 3:
				s.bindNTP();
				break;
		}
		
	}
	
	
}
