import java.io.FileInputStream;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

public class XMLparser {

	
	public static void parse(String filename) throws XMLStreamException, IOException {
		
		
		
		Model templateModel = new Model();
		
	    try (FileInputStream fis = new FileInputStream(filename)) {
	        XMLInputFactory xmlInFact = XMLInputFactory.newInstance();
	        XMLStreamReader reader = xmlInFact.createXMLStreamReader(fis);
	        while(reader.hasNext()) {
	        	
	        
	        	
	            reader.next();
	            //if (reader.hasName()) System.out.println(reader.getName());
	            
	            
	        	if (reader.hasName() && !reader.isEndElement()){
	        		
	        		

        			// Parse the default model settings
        			if (reader.getName().toString().equals("elongation-model")){
        				
        				reader.next();
        				while (!(reader.hasName() && reader.getName().toString().equals("elongation-model"))){
        					
        					
        					if (reader.isEndElement() || reader.isWhiteSpace() || !reader.hasName()) {
        						reader.next();
        						continue;
        					}
        					
        					String modelProperty = reader.getName().toString();
        					String val = reader.getAttributeValue(0);
        					
        					//System.out.println(modelProperty + "," + val);
        					
        					if (modelProperty == "allowBacktracking") templateModel.set_allowBacktracking(val.equals("true"));
	        				if (modelProperty == "allowHypertranslocation") templateModel.set_allowHypertranslocation(val.equals("true"));
	        				if (modelProperty == "allowInactivation") templateModel.set_allowInactivation(val.equals("true"));
	        				if (modelProperty == "allowBacktrackWithoutInactivation") templateModel.set_allowBacktrackWithoutInactivation(val.equals("true"));
	        				if (modelProperty == "allowGeometricCatalysis") templateModel.set_allowGeometricCatalysis(val.equals("true"));
	        				if (modelProperty == "allowmRNAfolding") templateModel.set_allowmRNAfolding(val.equals("true"));
	        				if (modelProperty == "allowMisincorporation") templateModel.set_allowMisincorporation(val.equals("true"));
	        				if (modelProperty == "useFourNTPconcentrations") templateModel.set_useFourNTPconcentrations(val.equals("true"));
	        				if (modelProperty == "NTPbindingNParams") templateModel.set_NTPbindingNParams(Integer.parseInt(val));
	        				if (modelProperty == "currentTranslocationModel") templateModel.set_currentTranslocationModel(val);
        					
	        				if (modelProperty == "assumeBindingEquilibrium") templateModel.set_assumeBindingEquilibrium(val.equals("true"));
	        				if (modelProperty == "assumeTranslocationEquilibrium") templateModel.set_assumeTranslocationEquilibrium(val.equals("true"));
	        				reader.next();
        					
        				}
        			
        			}
        			
        			
        			// Parse the default parameters
        			else if (reader.getName().toString().equals("parameters")){
        				
        				reader.next();
        				while (!(reader.hasName() && reader.getName().toString().equals("parameters"))){
        					
        					
        					if (reader.isEndElement() || reader.isWhiteSpace() || !reader.hasName()) {
        						reader.next();
        						continue;
        					}
        					
        					String paramID = reader.getName().toString();
        					Parameter param = templateModel.getParameter(paramID);
        					if (param == null) {
        						reader.next();
        						continue;
        					}
        					
        					// Iterate through all attributes for this parameter
        					for (int i = 0; i < reader.getAttributeCount(); i ++){
    		        			
    		        			String attribute = reader.getAttributeLocalName(i);
    		        			String value = reader.getAttributeValue(i);
    		        			//System.out.println(attribute + "," + value);
    		        			
    		        			if (attribute == "distribution") param.setPriorDistribution(value);
    		        			else param.setDistributionParameter(attribute, Double.parseDouble(value));
    		        		}
        					
        					//System.out.println(modelProperty + "," + val);
        					
        					param.updateDistribution();
        					param.sample();
	        				reader.next();
        					
        				}
        			
        			}
        			
        			
        			// Parse the models to estimate
        			else if (reader.getName().toString().equals("estimated-models")){
        				
        				reader.next();
        				double weightSum = 0;
        				while (!(reader.hasName() && reader.getName().toString().equals("estimated-models"))){
        					
        					
        					if (reader.isEndElement() || reader.isWhiteSpace() || !reader.hasName()) {
        						reader.next();
        						continue;
        					}
        					
        					
        					Model model = new Model(templateModel);
        					
        					
        					// Iterate through all model settings and parameters
        					for (int i = 0; i < reader.getAttributeCount(); i ++){
    		        			
    		        			String attribute = reader.getAttributeLocalName(i);
    		        			String val = reader.getAttributeValue(i);
    		        			//System.out.println(attribute + "," + value);
    		        			
    		        			if (attribute == "id") model.setID(Integer.parseInt(val));
    		        			else if (attribute == "weight") {
    		        				weightSum += Integer.parseInt(val);
    		        				model.setModelPrior(Integer.parseInt(val));
    		        			}
    		        			else if (attribute == "allowBacktracking") model.set_allowBacktracking(val.equals("true"));
    		        			else if (attribute == "allowHypertranslocation") model.set_allowHypertranslocation(val.equals("true"));
    		        			else if (attribute == "allowInactivation") model.set_allowInactivation(val.equals("true"));
    		        			else if (attribute == "allowBacktrackWithoutInactivation") model.set_allowBacktrackWithoutInactivation(val.equals("true"));
    		        			else if (attribute == "allowGeometricCatalysis") model.set_allowGeometricCatalysis(val.equals("true"));
    	        				else if (attribute == "allowmRNAfolding") model.set_allowmRNAfolding(val.equals("true"));
    	        				else if (attribute == "allowMisincorporation") model.set_allowMisincorporation(val.equals("true"));
    	        				else if (attribute == "useFourNTPconcentrations") model.set_useFourNTPconcentrations(val.equals("true"));
    	        				else if (attribute == "NTPbindingNParams") model.set_NTPbindingNParams(Integer.parseInt(val));
    	        				else if (attribute == "currentTranslocationModel") model.set_currentTranslocationModel(val);
    	        				else if (attribute == "assumeBindingEquilibrium") model.set_assumeBindingEquilibrium(val.equals("true"));
    	        				else if (attribute == "assumeTranslocationEquilibrium") model.set_assumeTranslocationEquilibrium(val.equals("true"));
    	        				else if (model.getParameter(attribute) != null) {
    	        					model.getParameter(attribute).setDistributionParameter("fixedDistributionVal", Double.parseDouble(val));
    	        					model.getParameter(attribute).setPriorDistribution("Fixed");
    	        				}
    	        				 
    		        		}
        					
        					
        					
        					
        					//System.out.println(modelProperty + "," + val);
        					Settings.models.add(model);
	        				reader.next();
        					
        				}
        				
        				// Convert the weights into log prior probabilities
        				for (int i = 0; i < Settings.models.size(); i ++){
        					double priorProb = Settings.models.get(i).getModelPrior() / weightSum;
        					Settings.models.get(i).setModelPrior(Math.log(priorProb));
        				}
        				
        			
        			}
	        		
	        		
	        		
        			else {
		        		for (int i = 0; i < reader.getAttributeCount(); i ++){
		        			
		        			String attribute = reader.getAttributeLocalName(i);
		        			String value = reader.getAttributeValue(i);
		        			//System.out.println(attribute + "," + value);
		        			
		        			
		        			if (reader.getName().toString().equals("session") && attribute == "N") Settings.ntrials_sim = Integer.parseInt(value);
		        			
		        			
		        			// Parse sequence information
		        			else if (reader.getName().toString().equals("sequence") && attribute == "seqID") Settings.seqID = value;
		        			else if (reader.getName().toString().equals("sequence") && attribute == "seq") Settings.seq = value;
		        			else if (reader.getName().toString().equals("sequence") && attribute == "TemplateType") Settings.TemplateType = value;
		        			else if (reader.getName().toString().equals("sequence") && attribute == "PrimerType") Settings.PrimerType = value;
		        			
		        			
		        			// Parse ABC settings
		        			else if (reader.getName().toString().equals("ABC") && attribute == "inferenceMethod") Settings.inferenceMethod = value;
		        			else if (reader.getName().toString().equals("ABC") && attribute == "ntrials") Settings.ntrials_MCMC = Integer.parseInt(value);
		        			else if (reader.getName().toString().equals("ABC") && attribute == "testsPerData") Settings.testsPerData = Integer.parseInt(value);
		        			else if (reader.getName().toString().equals("ABC") && attribute == "logEvery") Settings.logEvery = Integer.parseInt(value);
		        			else if (reader.getName().toString().equals("ABC") && attribute == "chiSqthreshold_min") Settings.chiSqthreshold_min = Double.parseDouble(value);
		        			else if (reader.getName().toString().equals("ABC") && attribute == "chiSqthreshold_0") Settings.chiSqthreshold_0 = Double.parseDouble(value);
		        			else if (reader.getName().toString().equals("ABC") && attribute == "chiSqthreshold_gamma") Settings.chiSqthreshold_gamma = Double.parseDouble(value);
		        			else if (reader.getName().toString().equals("ABC") && attribute == "burnin") Settings.burnin = Double.parseDouble(value);
		        		}
		        		
		        		
		        		// Experimental observations for ABC
		        		if (reader.getName().toString().equals("ABC")) {
		        			
		        			
		        			reader.next();
	        				while (!(reader.hasName() && reader.getName().toString().equals("ABC"))){
	        					
	        					
	        					if (reader.isEndElement() || reader.isWhiteSpace() || !reader.hasName()) {
	        						reader.next();
	        						continue;
	        					}
	        					
	        					
	        					String dataType = "";
	        					double ATPconc = -1;
	        					double CTPconc = -1;
	        					double GTPconc = -1;
	        					double UTPconc = -1;
	        					double force = 0;
	        					
	        					
	        					// Iterate through all attributes for this experiment
	        					for (int i = 0; i < reader.getAttributeCount(); i ++){
	    		        			
	    		        			String attribute = reader.getAttributeLocalName(i);
	    		        			String value = reader.getAttributeValue(i);
	    		        			//System.out.println(attribute + "," + value);
	    		        			
	    		        			if (attribute == "dataType") dataType = value;
	    		        			else if (attribute == "ATPconc") ATPconc = Double.parseDouble(value);
	    		        			else if (attribute == "CTPconc") CTPconc = Double.parseDouble(value);
	    		        			else if (attribute == "GTPconc") GTPconc = Double.parseDouble(value);
	    		        			else if (attribute == "UTPconc") UTPconc = Double.parseDouble(value);
	    		        			else if (attribute == "force") force = Double.parseDouble(value);
	    		        			
	    		        		}
	        					
	        					
	        					ExperimentalData data = new ExperimentalData(Settings.experiments.size()+1, dataType);
	        					data.setConcentrations(ATPconc, CTPconc, GTPconc, UTPconc);
	        					if (dataType.equals("ntpVelocity")) data.setforce(force);
	        					
	        					
	        					
	        					// Add the experimental observations
	        					for (int i = 0; i < reader.getAttributeCount(); i ++){
	    		        			
	    		        			String attribute = reader.getAttributeLocalName(i);
	    		        			
	    		        			// Skip if it does not have format "obsXXX"
	    		        			Pattern p = Pattern.compile("obs[0-9]+");
	    		        			Matcher m = p.matcher(attribute);
	    		        			if (!m.find()) continue; 
	    		        			
	    		        			String value = reader.getAttributeValue(i);
	    		        			String[] bits = value.split(",");
	    		        			double x = Double.parseDouble(bits[0]);
	    		        			double y = Double.parseDouble(bits[1]);
	    		        			data.addObservation(x, y);
	    		        			
	    		        			
	    		        		}
	        				
	        					Settings.experiments.add(data);
		        				reader.next();
	        					
	        				}
		        		}
		        		
        			}
	        		
	        		
	        	}
	            
	        }
	        
	        
	        if (Settings.models.size() == 0) Settings.models.add(templateModel);
	        Settings.sampleParameters();
	        //Settings.printSettings();
	        
	        
	    }
	}
	
	

}
